#include <iostream>
#include <algorithm>
#include <cstring>
#include <string>
#include <cstdio>
#include <set>
#include <vector>
#include <ctime>
#include <sstream>
#include <cstdlib>
#include <cmath>
#include <fstream>
using namespace std;

double w[100];//�����õ�����
double bestw[100];
double train[10000][100];//������5000��train���� 
double vali[5000][100];
double test[2500][100];
int label[10000];//ÿ�������ı�ǩ�������� 
int valilabel[10000];
double p_label[10000];
int Length;//w��train�����ĳ��� 
int traincnt;//������ 
int testcnt;
int valicnt;
double Weight[10000];
double Cost[100];
double accuracy;
double best_acc;
int cnt;
double ac[100000];

void Readtrain();
void Readtest();
void CalWeight()
{
	for(int i=0;i<traincnt;i++)
	{
		for(int j=0;j<Length;j++)
		{
			Weight[i]+=w[j]*train[i][j];
		}		
	}
}
void CalCost()
{
	for(int i=0;i<Length;i++)
	{
		for(int j=0;j<traincnt;j++)
		{
			Cost[i]+=((1/(1+exp(-1*Weight[j])))-label[j])*train[j][i];
		}	
		
	}
}
void Updatew()
{
	double alpha=0.1;
	alpha=0.01+1/(1+0.1*(cnt+1));
	for(int i=0;i<Length;i++) 
		w[i]=w[i]-alpha*Cost[i]/5000;
}

void Predict(string s)
{
	double P;
	if(s=="test") 
	{
		for(int i=0;i<testcnt;i++)
		{
			double sum=0;
			for(int j=0;j<Length;j++)
			{
				sum+=test[i][j]*w[j];
			}
			P=1/(1+exp(-1*sum));
			if(P>=0.5&&P<=1) p_label[i]=1;
			else if(P<0.5&&P>=0) p_label[i]=0;
		}
	}
	else if(s=="vali")
	{
		for(int i=0;i<valicnt;i++)
		{
			double sum=0;
			for(int j=0;j<Length;j++)
			{
				sum+=vali[i][j]*w[j];
			}
			P=1/(1+exp(-1*sum));
			if(P>=0.5&&P<=1) p_label[i]=1;
			else if(P<0.5&&P>=0) p_label[i]=0;
			else{cout<<"???";
			}			
		}
	}	
}
void Cal_acc()
{
	double right=0;
	for(int i=0;i<valicnt;i++)
	{
		if(p_label[i]==valilabel[i]) right++;
	}
	
	accuracy=right/valicnt;

}
void output_result()
{
	ofstream fout;
	fout.open("LR0.CSV");
	for(int i=0;i<cnt;i++)
	{
		fout<<ac[i]<<',';
	}		
	fout.close();
}
int main()
{
	Readtrain();
	//Readtest();
	double sum=0;
	cout<<"Length="<<Length<<"   traincnt="<<traincnt<<"  valicnt"<<valicnt<<endl;
	for(int i=0;i<Length;i++) w[i]=1;
	int time=400;
	best_acc=0;
	cnt=0;
	while(time--)
	{
		memset(Cost,0,sizeof(Cost));
		memset(Weight,0,sizeof(Weight));
		CalWeight();//����ÿһ��������Ȩ�� ���� 
		//cout<<"Weight1 "<<Weight[0]<<endl;
		CalCost();//ÿһά���ݶȼ��� 
		//cout<<"Cost1"<<Cost[0]<<endl;
		Updatew();//����ÿһά��Ȩ�� 
		Predict("vali");//������µ�w����Ԥ�� 
		Cal_acc();//����׼ȷ�� 
		cout<<"Accuracy:"<<accuracy<<endl;
		if(accuracy>best_acc) best_acc=accuracy;
		ac[cnt]=accuracy;
		cnt++;
	}
	cout<<"b"<<best_acc;
	output_result();
	
} 





void Readtrain()
{
	ifstream fin("train.csv");
	string line;
	vector<string> fields;
	traincnt=0;
	valicnt=0;
	int mo=3;
	int cnt=1;
	while(getline(fin,line))
	{
		fields.clear();
		istringstream sin(line);		
		string field;
		while(getline(sin,field,','))
		{
			fields.push_back(field);
		}	
		train[traincnt][0]=1;
		vali[valicnt][0]=1;
		for(int i=0;i<fields.size();i++)
		{
			double temnum;
			stringstream ss;
			ss.clear();
			ss.str(fields[i]);
			ss>>temnum;			
			if(cnt%mo==0)
			{
				if(i==fields.size()-1) {
					valilabel[valicnt]=temnum;
					valicnt++;
				}
				else vali[valicnt][i+1]=temnum;
				
			}
			else
			{
				if(i==fields.size()-1) 
				{
					label[traincnt]=temnum;
					traincnt++;
				}
				else train[traincnt][i+1]=temnum;				
			}
		}				
		cnt++;
		Length=fields.size();
	}
}

void Readtest()
{
	ifstream fin("mtest.csv");
	string line;
	vector<string> fields;
	testcnt=0;
	while(getline(fin,line))
	{
		fields.clear();
		istringstream sin(line);		
		string field;
		while(getline(sin,field,','))
		{
			fields.push_back(field);
		}	
		test[testcnt][0]=1;
		for(int i=0;i<fields.size()-1;i++)
		{
			double temnum;
			stringstream ss;
			ss.clear();
			ss.str(fields[i]);
			ss>>temnum;
			test[testcnt][i+1]=temnum;
		}
		testcnt++;
	}
}












