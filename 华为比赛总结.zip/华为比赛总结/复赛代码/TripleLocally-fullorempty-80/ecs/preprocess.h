#include <iostream>
#include <algorithm>
#include <string>
#include <cstdio>
#include <set>
#include <vector>
#include <ctime>
#include <sstream>
#include <cstdlib>
#include <cmath>
#include <fstream>

using namespace std;

void Initial()
{
	cout<<"FlavorCdM:";
	for(int i=1;i<=18;i++){
		FlavorCdM[i]=(double)FlavorCPU[i]/(double)FlavorMEM[i];
		cout<<FlavorCdM[i]<<" ";
	}
	cout<<endl;
}

void GetDate(string str){
	string year="",month="",date="";
	int which=0;
	for(int j=0;j<(int)str.size();j++){
		if(str[j]=='-') which++;
		if(which==0&&str[j]!='-')	year=year+str[j];
		else if(which==1&&str[j]!='-')	month+=str[j];
		else if(which==2&&str[j]!='-')	date+=str[j];
	}
	//cout<<year<<" "<<month<<" "<<date<<" ";
	stringstream sss;
	sss.clear();
	sss.str(year);
	sss>>yearnum;	
	sss.clear();
	sss.str(month);
	sss>>monthnum;
	sss.clear();
	sss.str(date);
	sss>>datenum;
	int day_code,s=0,a[12]={31,28,31,30,31,30,31,31,30,31,30,31};
	day_code=(yearnum+(yearnum-1)/4-(yearnum-1)/100+(yearnum-1)/400)%7;
	for(int k=0;k<monthnum-1;k++)
		s=s+a[k];
	s=s+datenum;
	if(yearnum%4==0) s=s+1;
	daynum=(s+day_code-1)%7;
	//cout<<daynum<<endl;
}

void ReadTrainData(char* data[MAX_DATA_NUM],int data_num)
{
	int sample_cnt=0;
	for(int i=0;i<data_num;i++)
	{
		string line=data[i];
		istringstream istr (line);
		int type_num=0;
	    string date_str;	    
	    for(int j=0;j<4;j++){
	    	string part;
			istr>>part;
			if(j==1){//flavor
				string num;
				if(part.size()==7) num=part.substr(6,1);
				else if(part.size()==8) num=part.substr(6,2);
				else cout<<"ReadData Error!\n";
				type_num=atoi(num.c_str());
			}
			else if(j==2){
				date_str=part;
			}
		}
		sample[sample_cnt].date=date_str;
		sample[sample_cnt].type=type_num;
		sample_cnt++;
	}
	SampleCnt=sample_cnt;
//	for(int i=0;i<sample_cnt;i++){
//		cout<<sample[i].date<<"	"<<sample[i].type<<endl;
//	}	
}

struct Day
{
	int FlavorCnt[20];
	string date;
	Day(){
		for(int i=0;i<20;i++) FlavorCnt[i]=0;
	}
};
Day day[3000];
int day_cnt=0;
void DayForm()
{
	string pre_date=sample[SampleCnt-1].date;//ǰһ�������ַ��� 
	day[0].date=sample[SampleCnt-1].date;
	for(int i=0;i<SampleCnt;i++)
	{
		int convert_i=SampleCnt-i-1;
		string date_str=sample[convert_i].date;//��������������ַ��� 
		int type_int=sample[convert_i].type;//������������������ 
		if(type_int>=19) continue;
		if(pre_date!=date_str){//����һ���µ����ڣ�����һ���������ڵ�ǰһ��
			day_cnt++;
			day[day_cnt].FlavorCnt[type_int]++;
			day[day_cnt].date=date_str;
		}
		else{
			day[day_cnt].FlavorCnt[type_int]++;
		}
		pre_date=date_str;		
	}
	Day temday[3000];
	
	int temdrop=day_cnt%DatePeriod;//ǰ���������� 
	day_cnt=day_cnt-temdrop;
	for(int i=0;i<day_cnt;i++){
		temday[i]=day[i];
	} 
	for(int i=0;i<day_cnt;i++){
		day[i]=temday[day_cnt-1-i];
	}
	TrainEndingDate=day[day_cnt-1].date;
//	for(int i=0;i<day_cnt-temdrop;i++)
//	{
//		cout<<"date:"<<day[i].date<<endl;
//		for(int j=1;j<=15;j++){
//			cout<<"flavor"<<j<<": "<<day[i].FlavorCnt[j]<<endl;
//		}
//	}
}

void GaussDay(double borderline)
{
	double average=0;
	double std_deviation=0;
	for(int i=0;i<vir_cnt;i++){
		int type=ChosenType[i];
		double sum=0;
		for(int j=0;j<day_cnt;j++)	
			sum+=day[j].FlavorCnt[type];		
		average=sum/day_cnt;
		for(int j=0;j<day_cnt;j++){
			std_deviation+=(day[j].FlavorCnt[type]-average)*(day[j].FlavorCnt[type]-average);			
		}
		std_deviation/=day_cnt;
		std_deviation=sqrt(std_deviation);
		cout<<"type"<<type<<" average="<<average<<" std_deviation="<<std_deviation<<endl;
		for(int j=0;j<day_cnt;j++){
			if(day[j].FlavorCnt[type]>average+borderline*std_deviation)
			{
				cout<<"daybigggggggggg"<<endl;
				day[j].FlavorCnt[type]=average+borderline*std_deviation;
			}
			else if(day[j].FlavorCnt[type]<average-borderline*std_deviation)
			{
				cout<<"????"<<endl;
				day[j].FlavorCnt[type]=average-borderline*std_deviation;
			}
		}
	}	
}
struct Period
{
	double FlavorCnt[20];
	string start_date,end_date;
	Period(){
		for(int i=0;i<20;i++) FlavorCnt[i]=0;
	}
};
Period period[3000];
int period_cnt=0;
void PeriodForm(int period_size)
{
	int temcnt=0;//���˶��ٸ���
	string pre_date=day[0].date;
	period[0].start_date=day[0].date;
	for(int i=0;i<day_cnt;i++)
	{
		if(temcnt>=period_size){//�չ���һ������ 
			period[period_cnt].end_date=pre_date;
			period_cnt++;
			temcnt=0;
			period[period_cnt].start_date=day[i].date;
		}
		for(int k=1;k<=18;k++){
			period[period_cnt].FlavorCnt[k]+=day[i].FlavorCnt[k];
		}
		pre_date=day[i].date;
		temcnt++;
	}
	period_cnt++;
//	for(int i=0;i<period_cnt;i++)
//	{
//		cout<<"start_date:"<<period[i].start_date<<"end_date:"<<period[i].end_date<<endl;
//		for(int j=1;j<=15;j++){
//			cout<<"flavor"<<j<<": "<<period[i].FlavorCnt[j]<<endl;
//		}
//	}
}
double Average[20];
double Std[20];
void GaussNoise()
{
	double average=0;
	double std_deviation=0;
	for(int i=0;i<vir_cnt;i++){
		int type=ChosenType[i];
		double sum=0;
		for(int j=0;j<period_cnt;j++)	
			sum+=period[j].FlavorCnt[type];		
		average=sum/period_cnt;
		Average[type]=average;
		for(int j=0;j<period_cnt;j++){
			std_deviation+=(period[j].FlavorCnt[type]-average)*(period[j].FlavorCnt[type]-average);			
		}
		std_deviation/=period_cnt;
		std_deviation=sqrt(std_deviation);
		cout<<"type"<<type<<" average="<<average<<" std_deviation="<<std_deviation<<endl;
		Std[type]=std_deviation;

//		//������һ����ʵûʲô�ã��������0.3 
		for(int j=0;j<period_cnt;j++){
			if(period[j].FlavorCnt[type]>average+2*std_deviation)
			{
				cout<<"!!!!!!!!!!!!!!!!"<<endl;
				period[j].FlavorCnt[type]=average+2*std_deviation;						
			}
			else if(period[j].FlavorCnt[type]<average-2*std_deviation)
			{
				cout<<"!!!!!!!!!!!!!!!!"<<endl;
				period[j].FlavorCnt[type]=average-2*std_deviation;
			//	if(period[j].FlavorCnt[type]<0) period[j].FlavorCnt[type]=1;
			}
		}
		
	}	
}

string PHYNAME[3];//���������������� 
double PHYCPU[3];//������������CPU���� 
double PHYMEM[3];//������������MEM���� 
double PHYCdM[3];//��ͬ����������CPU/MEM 
int PHY_TYPE_CNT=0;//�ж����������� 
void ReadInputText(char* info[MAX_INFO_NUM])
{
	int phy_type_cnt=0; 
	int temcnt=0;
	bool flag_finish=false;
	for(int i=0;i<10000;i++)
	{
		if(flag_finish==true) break;
		string line=info[i];
		istringstream istr (line);	
		if(i==0){
			istr>>phy_type_cnt;
		}
		else if(i>=1&&i<1+phy_type_cnt){
			string temtype;	
			int cpu,mem,disk;
			istr>>temtype;
			istr>>cpu>>mem>>disk;
			PHYCPU[PHY_TYPE_CNT]=cpu;
			PHYMEM[PHY_TYPE_CNT]=mem;
			PHYNAME[PHY_TYPE_CNT]=temtype;
			PHY_TYPE_CNT++;
		}
		else if(i==1+phy_type_cnt) continue;
		else if(i==2+phy_type_cnt){
			istr>>vir_cnt;
		}
		else if(i>=3+phy_type_cnt&&i<3+phy_type_cnt+vir_cnt){
			string temtype;	
			istr>>temtype;
			if(temtype.size()==7) ChosenType[temcnt]=atoi(temtype.substr(6,1).c_str());
			else if(temtype.size()==8) ChosenType[temcnt]=atoi(temtype.substr(6,2).c_str());
			temcnt++;
		}
		else if(i==3+phy_type_cnt+vir_cnt) continue;
		else if(i==4+phy_type_cnt+vir_cnt){
			istr>>start_date;
			istr>>start_time;
		}
		else if(i==5+phy_type_cnt+vir_cnt){
			istr>>end_date;
			istr>>end_time;
			flag_finish=true;
		}	
	}
	cout<<vir_cnt<<" "<<start_date<<" "<<end_date<<endl;
	for(int i=0;i<temcnt;i++){
		cout<<"type"<<ChosenType[i]<<" ";
	}
	cout<<endl;
	
	for(int i=0;i<PHY_TYPE_CNT;i++) {
		PHYCdM[i]=PHYCPU[i]/PHYMEM[i];
		cout<<"PHYCdM[i]="<<PHYCdM[i]<<endl;
	}
	
	tagDate date1, date2;  
	GetDate(start_date);
	SetDate(yearnum,monthnum,datenum, &date1); 
	GetDate(end_date);
	SetDate(yearnum,monthnum,datenum, &date2); 
	DatePeriod=DateDiff(date1,date2);
	char firstchar=end_time[0];
	if(firstchar=='2') DatePeriod++;//�����˵��ֹ������23:59:59 
	cout<<"���"<<DatePeriod<<"��\n";

}



