#include <iostream>
#include <algorithm>
#include <string>
#include <cstdio>
#include <set>
#include <vector>
#include <ctime>
#include <sstream>
#include <cstdlib>
#include <cmath>
#include <fstream>

using namespace std;


void TriplePredict()
{
	double S[4][10000];
	for(int i=1;i<=18;i++){
		PredictRes[i]=0;
	}
	for(int i=0;i<vir_cnt;i++)
	{
		int type=ChosenType[i];//��ҪԤ������������
		S[1][0]=period[0].FlavorCnt[type]+period[1].FlavorCnt[type]+period[2].FlavorCnt[type];//+period[period_cnt-4].FlavorCnt[type];
		S[1][0]/=3;
		S[2][0]=S[1][0];
		S[3][0]=S[1][0];
		double a=0.02;
		for(int j=1;j<period_cnt;j++)
		{
			S[1][j]=a*period[j].FlavorCnt[type]+(1-a)*S[1][j-1];
			S[2][j]=a*S[1][j]+(1-a)*S[2][j-1];
			S[3][j]=a*S[2][j]+(1-a)*S[3][j-1];
		}
		double St1=S[1][period_cnt-1],St2=S[2][period_cnt-1],St3=S[3][period_cnt-1];
		double at=3*St1-3*St2+St3;
		double bt=((6-5*a)*St1-2*(5-4*a)*St2+(4-3*a)*St3)  *a/(1-a)/(1-a)/2;
		double ct=	(St1-2*St2+St3)	*a*a/(1-a)/(1-a)/2;
		cout<<"type"<<type<<"at="<<at<<"bt="<<bt<<"ct="<<ct<<endl;
		
		for(int j=IntervalPeriod+1;j<IntervalPeriod+DatePeriod+1;j++)
		{
			PredictRes[type]+=at+bt*j+ct*j*j;
		}
		
		//PredictRes[type]=at+bt+ct;//+bt+ct;
		
	
		
//		if(PredictRes[type]<Average[type]-2*Std[type]) PredictRes[type]=Average[type]-2.06*Std[type];
//		else if(PredictRes[type]>Average[type]+2*Std[type]) PredictRes[type]=Average[type]+2.06*Std[type];

//		if(PredictRes[type]>1.4*period[period_cnt-1].FlavorCnt[type]) PredictRes[type]=1.4*period[period_cnt-1].FlavorCnt[type];
//		if(PredictRes[type]<0.6*period[period_cnt-1].FlavorCnt[type]) PredictRes[type]=0.6*period[period_cnt-1].FlavorCnt[type];

		if(PredictRes[type]<=0) PredictRes[type]=period[period_cnt-1].FlavorCnt[type];
	}

	for(int i=1;i<=18;i++){
		cout<<"PredictRes"<<i<<" " <<PredictRes[i]<<endl;
	}
	
}





