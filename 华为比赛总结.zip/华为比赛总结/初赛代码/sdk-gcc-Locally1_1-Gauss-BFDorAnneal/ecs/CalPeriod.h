#include <stdio.h>
#include <string.h>
#include <iostream>
#include <algorithm>
#include <string>
#include <cstdio>
#include <set>
#include <vector>
#include <ctime>
#include <sstream>
#include <cstdlib>
#include <cmath>
#include <fstream>

struct tagDate//���ڼ���Ԥ�����������  
{   
    int year;  
    int month;  
    int day;  
};  

void SetDate(int y, int m, int d, tagDate *date)  //��������  
{   
    date->year = y;  
    date->month = m;  
    date->day = d;  
}   
int IsLeapYear(int year)    //�Ƿ�����  
{   
    return ((year%4==0&&year%100!=0)||year%400==0);   
}   
int GetLastDay(tagDate date)   //�õ�date.month���������  
{   
    int num;  
    switch(date.month)   
    {  
    case 1:  
    case 3:  
    case 5:  
    case 7:  
    case 8:  
    case 10:  
    case 12:  
        num=31;  
        break;  
    case 2:  
        num = 28+IsLeapYear(date.year);   
        break;   
    default:   
        num = 30;   
    }   
    return num;   
}  
void AddDay(tagDate *date)  //date+1  
{  
    date->day++;  
    if(date->day > GetLastDay(*date))  
    {  
        date->day = 1;  
        date->month++;  
        if(date->month > 12)  
        {  
            date->month = 1;  
            date->year++;  
        }  
    }  
}  
int Compare(tagDate date1, tagDate date2)  //date1��date2С����ֵΪ1������Ϊ0  
{  
    if(date1.year < date2.year)  
        return 1;  
    if(date1.year <= date2.year && date1.month < date2.month)  
        return 1;  
    if(date1.year <= date2.year && date1.month <= date2.month && date1.day < date2.day)  
        return 1;  
  
    return 0;  
}   
long DateDiff(tagDate date1, tagDate date2)  //�����������ڵļ������  
{  
    long delta = 0;  
    tagDate date3;  
    //��date1 > date2,����date1,date2  
    if(!Compare(date1, date2))  
    {  
        date3 = date2;  
        date2 = date1;  
        date1 = date3;  
    }  
    //date1��date2��ʱ��date1���ڼ�1  
    while(Compare(date1,date2))  
    {  
        AddDay(&date1);  
        delta++;  
    }  
    return delta;  
}   
