#include <iostream>
#include <algorithm>
#include <iomanip>
#include <cstring>
#include <string>
#include <fstream>
#include <cassert>
#include <cstdio>
#include <map>
#include <vector>
#include <ctime>
#include <cstdlib>
#include <cmath>
#include <sstream>
using namespace std;
double matrix[3000][3000];//������� 
string word_matrix[1300][50];//�����������õĶ�ά���� 
double num[1300];//ÿһ�仰�� ���������� 
vector<string> word;
int num_of_word=0;//�ܹ��ĵ������� 

string my_label[1000];
int train_num,vali_num;
double actual[6][1000],predict[6][1000];
void getword(string s,int row)
{
	int cnt=0;
	stringstream ss;
	ss.clear();
	ss.str(s);
	while(ss)
	{		
		ss>>word_matrix[row][cnt++];
	}
	num[row]=cnt-1;
}
void setlabel(double temnum,int row,int cnt)
{
	actual[cnt][row]=temnum;
}
void getlabel(string l,int row)
{
	int start=0,end;
	double temnum;
	int cnt=0;
	for(int i=0;i<l.size();i++)
	{
		if(l[i]==','||i==l.size()-1)
		{
			if(l[i]==',') end=i-1;
			else end=i;
			string tems=l.substr(start,end-start+1);
			start=i+1;
			
			stringstream ss;
			ss.clear();
			ss.str(tems);
			ss>>temnum;
			setlabel(temnum,row,cnt++);
		}		
	}
}

void TF(int row,int train_num)
{
	for(int i=0;i<row;i++)
	{
		for(int j=0;j<num[i];j++)
		{
			vector<string>::iterator index=find(word.begin(),word.end(),word_matrix[i][j]);
			int pos=distance(word.begin(),index);
			if(index!=word.end())//���ֹ� 
			{
				matrix[i][pos]++;
			}
			else if(i<train_num)//�µ��� ,��֤�����µ��ʺ��� 
			{				
				word.push_back(word_matrix[i][j]);
				num_of_word++;
				matrix[i][num_of_word-1]=1;
			}		
		}
	}
	double coe=0.009;
	for(int i=0;i<train_num;i++)
	{
		for(int j=0;j<num_of_word;j++)
		{
			if(num[i]!=0) matrix[i][j]=(matrix[i][j]+coe)/(num[i]+coe*num_of_word);		
			//if(num[i]!=0) matrix[i][j]=(matrix[i][j])/(num[i]);	
			//cout<<matrix[i][j]<<" ";
		}
		//cout<<endl;
	}
	
}

void Regress(int cur)
{
	double mood[6];
	for(int i=0;i<6;i++) mood[i]=0;
	double temlabel[6][1000];
	for(int i=0;i<6;i++)
		for(int j=0;j<train_num;j++) temlabel[i][j]=actual[i][j];
		
	for(int i=0;i<num_of_word;i++)
	{
		if(matrix[cur][i]==0) continue;
		for(int j=0;j<train_num;j++)
		{
			for(int z=0;z<6;z++)
			{
				temlabel[z][j]*=matrix[j][i];//mood[i]*=matrix[j][i]*actual[z][j];
			}
		}
	}
	for(int i=0;i<6;i++)
	{
		for(int j=0;j<train_num;j++)
		{
			mood[i]+=temlabel[i][j];
		}
	}
	for(int i=0;i<6;i++) predict[i][cur]=mood[i];
//	for(int i=0;i<6;i++) cout<<predict[i][cur]<<" ";
//	cout<<endl;
	
	double sum=0;
	for(int i=0;i<6;i++) sum+=predict[i][cur];
	for(int i=0;i<6;i++) 
	{
		if(sum!=0) predict[i][cur]/=sum;		
	}
	//for(int i=0;i<6;i++) cout<<predict[i][cur]<<" ";
	//cout<<endl;
	//cout<<"��Ԥ��ģ�"<<temmood<<endl;
	//cout<<"ʵ���ϣ�"<<Label[cur]<<endl<<endl;
	
}

void NB_Regression()
{
	memset(matrix,0,sizeof(matrix));
	ifstream fin;	
	fin.open("train_set.csv");//�����������ļ� ����ͬһ��Ŀ¼����ָ��·��ֻ��Ҫ�ļ����� 
	string s;
	int row=0;
	getline(fin,s);
	while(getline(fin,s)) 
	{	
		int comma=s.find(',');//Ѱ�Ҷ��� 
		string ss=s.substr(0,comma);//substr(a,b)��ȡ�ӵ�aλ�ÿ�ʼ����Ϊb���ַ���
		string label=s.substr(comma+1);
		getword(ss,row);		
		getlabel(label,row);
		row++;		
		//if(row>5)	break;
	} 
	train_num=row;
	fin.close();
	cout<<train_num<<endl;

	fin.open("validation_set.csv");//�����������ļ� ��ͬһ��Ŀ¼����ָ��·��ֻ��Ҫ�ļ����� 
	getline(fin,s);
	while(getline(fin,s)) 
	{	
		int comma=s.find(',');//Ѱ�Ҷ��� 
		string ss=s.substr(0,comma);//substr(a,b)��ȡ�ӵ�aλ�ÿ�ʼ����Ϊb���ַ���
		string label=s.substr(comma+1);
		getword(ss,row);		
		getlabel(label,row);
		row++;
		//if(row>6) break;
	} 
	vali_num=row-train_num;
	fin.close();
	cout<<vali_num<<endl;
	TF(row,train_num);
	
	
	//int limit=train_num+15;
	int limit=row;
	for(int i=train_num;i<limit;i++)
	{
		Regress(i);		
	}
	
//	int cnt0=1;	
//	for(int i=train_num;i<limit;i++)	
//	{
//		cout<<cnt0++;
//		for(int j=0;j<6;j++)
//		{
//			cout<<','<<predict[j][i];
//		}
//		cout<<endl;
//	}
		
	ofstream fout;
	fout.open("15352446_NB_regression.csv");
	fout<<"textid,anger,disgust,fear,joy,sad,surprise\n";
	int cnt=1;
	for(int i=train_num;i<limit;i++)	
	{
		fout<<cnt++;
		for(int j=0;j<6;j++)
		{
			fout<<','<<predict[j][i];
		}
		fout<<endl;
	}
	fout.close();
}
int main()
{
	NB_Regression();

} 





