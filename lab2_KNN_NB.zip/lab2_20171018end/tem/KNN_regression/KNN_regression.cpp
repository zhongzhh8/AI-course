#include <iostream>
#include <algorithm>
#include <iomanip>
#include <cstring>
#include <string>
#include <fstream>
#include <cassert>
#include <cstdio>
#include <map>
#include <vector>
#include <ctime>
#include <cstdlib>
#include <cmath>
#include <sstream>
using namespace std;
double matrix[3000][3000];//������� 
string word_matrix[1300][50];//�����������õĶ�ά���� 
double num[1300];//ÿһ�仰�� ���������� 
vector<string> word;
double idf[5000];//ÿ�����ʣ��У���Ҫ�˵���ֵ�Եõ� TF_IDF���� 
int num_of_word=0;//�ܹ��ĵ������� 

string my_label[1000];
int train_num,vali_num;
string Label[1000];
double actual[6][1000],predict[6][1000];
void getword(string s,int row)
{
	int cnt=0;
	stringstream ss;
	ss.clear();
	ss.str(s);
	while(ss)
	{		
		ss>>word_matrix[row][cnt++];
	}
	num[row]=cnt-1;
}
void setlabel(double temnum,int row,int cnt)
{
	actual[cnt][row]=temnum;
}
void getlabel(string l,int row)
{
	int start=0,end;
	double temnum;
	int cnt=0;
	for(int i=0;i<l.size();i++)
	{
		if(l[i]==','||i==l.size()-1)
		{
			if(l[i]==',') end=i-1;
			else end=i;
			string tems=l.substr(start,end-start+1);
			start=i+1;
			
			stringstream ss;
			ss.clear();
			ss.str(tems);
			ss>>temnum;
			setlabel(temnum,row,cnt++);
		}		
	}
}
void get_idf(int train_num)
{
	for(int i=0;i<num_of_word;i++)//i��col�� 
	{
		double cnt=0;
		for(int j=0;j<train_num;j++)
		{
			if(matrix[j][i]!=0) cnt++;
		}
		if(cnt!=0) idf[i]=log(train_num/(cnt+1));
		else idf[i]=0;					
	}
}
void TF_IDF(int row,int train_num)
{
	
	for(int i=0;i<row;i++)
	{
		for(int j=0;j<num[i];j++)
		{
			vector<string>::iterator index=find(word.begin(),word.end(),word_matrix[i][j]);
			int pos=distance(word.begin(),index);
			if(index!=word.end())//���ֹ� 
			{
				matrix[i][pos]++;
			}
			else if(i<train_num)
			{
				word.push_back(word_matrix[i][j]);
				num_of_word++;
				matrix[i][num_of_word-1]=1;
			}		
		}
	}
	for(int i=0;i<row;i++)
	{
		for(int j=0;j<num_of_word;j++)
		{
			if(num[i]!=0) matrix[i][j]*=1/num[i];
			//cout<<matrix[i][j]<<" ";
		}
	//	cout<<endl;
	}
	
	get_idf(train_num);
	for(int i=0;i<num_of_word;i++)//i��col�� 
	{				
		for(int j=0;j<row;j++)
		{
			matrix[j][i]*=idf[i];
		}
	}
	for(int i=0;i<row;i++)
	{
		double sum=0;
		for(int j=0;j<num_of_word;j++)
		{
			sum+=matrix[i][j];
		}
		for(int j=0;j<num_of_word;j++) matrix[i][j]/=sum;
	}
}

double Distance(int a,int b)
{
	double A=0,B=0,AB=0;
	for(int i=0;i<num_of_word;i++)
	{
		A+=matrix[a][i];
		B+=matrix[b][i];
		AB+=matrix[a][i]*matrix[b][i];
	}
	A=sqrt(A);B=sqrt(B);
	double result=AB/(A*B);
	return result;//Խ��Խ�� 
}
void Regress(int cur)
{
	double Dis[1000];	
	for(int i=0;i<train_num;i++)
	{
		Dis[i]=Distance(i,cur);
	}
	int k=12;
	double maxx;
	int Index[30];
	double index_dis[30];
	for(int i=0;i<k;i++)
	{
		maxx=0;
		for(int j=0;j<train_num;j++)
		{
			if(Dis[j]>maxx) 
			{
				maxx=Dis[j];
				Index[i]=j;//Ŀǰ��С������Ǹ�ѵ������id 
				index_dis[i]=Dis[j];//Ŀǰ�������ֵ 
			}			
		}
		Dis[Index[i]]=0;
	}
	//���Ҿ����һ�� 
	
//	double max_dis=index_dis[0],min_dis=index_dis[k-1];
//	for(int i=0;i<k;i++)
//	{
//		index_dis[i]=(index_dis[i]-min_dis)/(max_dis-min_dis);
//	}
	
	for(int i=0;i<k;i++)
	{
		for(int j=0;j<6;j++)
		{			
			if(index_dis[i]!=0) predict[j][cur]+=actual[j][Index[i]]*index_dis[i];
		}
	}
	
	double sum=0;
	for(int i=0;i<6;i++) sum+=predict[i][cur];
	for(int i=0;i<6;i++) 
	{
		if(sum!=0) predict[i][cur]/=sum;
	}
	//for(int i=0;i<6;i++) cout<<predict[i][cur]<<" ";
//	cout<<endl;
	//cout<<"��Ԥ��ģ�"<<temmood<<endl;
	//cout<<"ʵ���ϣ�"<<Label[cur]<<endl<<endl;
	
}

void KNN_Regression()
{
	memset(matrix,0,sizeof(matrix));
	ifstream fin;	
	fin.open("train_set.csv");//�����������ļ� ����ͬһ��Ŀ¼����ָ��·��ֻ��Ҫ�ļ����� 
	string s;
	int row=0;
	getline(fin,s);
	while(getline(fin,s)) 
	{	
		int comma=s.find(',');//Ѱ�Ҷ��� 
		string ss=s.substr(0,comma);//substr(a,b)��ȡ�ӵ�aλ�ÿ�ʼ����Ϊb���ַ���
		string label=s.substr(comma+1);
		getword(ss,row);		
		getlabel(label,row);
		row++;		
		//if(row>5)	break;
	} 
	train_num=row;
	fin.close();
	cout<<train_num<<endl;

	fin.open("validation_set.csv");//�����������ļ� ��ͬһ��Ŀ¼����ָ��·��ֻ��Ҫ�ļ����� 
	getline(fin,s);
	while(getline(fin,s)) 
	{	
		int comma=s.find(',');//Ѱ�Ҷ��� 
		string ss=s.substr(0,comma);//substr(a,b)��ȡ�ӵ�aλ�ÿ�ʼ����Ϊb���ַ���
		string label=s.substr(comma+1);
		getword(ss,row);		
		getlabel(label,row);
		row++;
		//if(row>6) break;
	} 
	vali_num=row-train_num;
	fin.close();
	cout<<vali_num<<endl;
	TF_IDF(row,train_num);
	int limit=row;//train_num+15;
	for(int i=train_num;i<limit;i++)
	{
		Regress(i);		
	}
		
	ofstream fout;
	fout.open("15352446_KNN_regression.csv");
	fout<<"textid,anger,disgust,fear,joy,sad,surprise\n";
	int cnt=1;
	for(int i=train_num;i<row;i++)	
	{
		fout<<cnt++;
		for(int j=0;j<6;j++)
		{
			fout<<','<<predict[j][i];
		}
		fout<<endl;
	}
	fout.close();
}
int main()
{
	KNN_Regression();

} 





