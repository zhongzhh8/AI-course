#include <iostream>
#include <algorithm>
#include <cstring>
#include <cstdio>
#include <set>
#include <vector>
#include <ctime>
#include <cstdlib>
#include <cmath>
#include <fstream>
using namespace std;
struct Node
{
	Node* next;
	int row,col,value;
};
int cmp(Node* n1,Node* n2)
{
	if(n1->row>n2->row) return 1;
	else if(n1->row<n2->row) return -1;
	else
	{
		if(n1->col<n2->col) return -1;
		else if(n1->col>n2->col) return 1;
		else return 0;
	}
}
Node* createlist(int index)
{
	int row,col,num;	
	ifstream fin;
	if(index==1) fin.open("A.txt");
	else if(index==2) fin.open("B.txt");
	fin>>row>>col>>num;
	Node* head=new Node;
	head->row=row;	head->col=col;	head->value=num;	
	Node* p=head;
	for(int i=0;i<num;i++)
	{
		int x,y,z;
		fin>>x>>y>>z;
		Node* tem=new Node;
		tem->row=x;  tem->col=y;  tem->value=z;
		p->next=tem;
		tem->next=NULL;
		p=p->next;
	}
	
	fin.close();
	return head;
}
int main()
{
	Node*headA=createlist(1);
	Node*headB=createlist(2);
	int row=headA->row;
	int col=headA->col;
	int num=headA->value+headB->value;
	Node* p=headA->next;//�ı�1���� 
	Node* q=headB->next;//�ı�2���� 
	Node* head=new Node;//�½�����ͷ��� 
	Node* tem=head;
	while(p!=NULL&&q!=NULL)
	{
		if(cmp(p,q)==-1)//�ڵ�p��С 
		{
			tem->next=p;
			tem=tem->next;
			p=p->next;
		}
		else if(cmp(p,q)==1)//�ڵ�q��С 
		{
			tem->next=q;
			tem=tem->next;
			q=q->next;
		}
		else//�ڵ�λ����ͬ 
		{		
			p->value=p->value+q->value;
			tem->next=p;
			tem=tem->next;
			p=p->next;
			q=q->next;
			num--;
		}
	}
	if(p!=NULL) tem->next=p;
	else tem->next=q;
	ofstream fout;
	fout.open("C.txt");
	fout<<row<<endl<<col<<endl<<num<<endl;
	q=head->next;
	while(q!=NULL)
	{
		fout<<q->row<<" "<<q->col<<" "<<q->value<<endl;
		q=q->next;
	}	
} 














